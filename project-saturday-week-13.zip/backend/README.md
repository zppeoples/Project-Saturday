# Project Saturday league service

GitHub Pages serves the public website. The Cloudflare Worker uses D1 for league updates and private interviews. The 2027 baseline opens on Week 13. The Week 13 standings reflect the current in-game snapshot. The schedule retains the verified earlier results.

## Local review

From the repository root, run `node backend/local-preview.mjs` with Node 24 or newer. Open the loopback URL it prints and use the temporary key on the Commissioner tab. The preview uses the real Worker routes and SQL against an in-memory SQLite database. Stopping it clears preview edits. A second browser session can open a private coach link while the preview is running.

## Production after approval

1. Create the `project-saturday` D1 database in the Cloudflare account that will own the service. Put its ID into `backend/wrangler.toml`.
2. From `backend/`, run `npx wrangler d1 migrations apply project-saturday --remote` and `npx wrangler deploy`.
3. Set a randomly generated commissioner key of at least 32 characters with `npx wrangler secret put COMMISSIONER_KEY`. Keep the key in a password manager. Set `SITE_ORIGIN` to the exact Pages origin if the domain changes.
4. Add the Worker’s HTTPS origin in `league-config.js` and publish the approved frontend to GitHub Pages.
5. Sign in and publish the baseline once. Share coach links directly with their intended team owners. Replace a link in Commissioner HQ to invalidate an unanswered link. Answers appear publicly on submission. The coach link grants access to that interview, so treat it like a password.

The dashboard uses official standings and ranking entries supplied by the commissioner. Published answers appear under the relevant game and on the Media tab. Use the Headlines & stories section to promote a game or published coach quote.

## 2027 results and PP BCS source notes

Use the commissioner's latest corrections and 2027 in-game screenshots for final scores and result types. The project screenshots IMG_2117 through IMG_2122 supply Weeks 9 and 10. Cross-conference games shown on two conference screens appear once. IMG_2217 through IMG_2222 supply Weeks 11 and 12. Week 13 starts with the four commissioner-reported CPU finals. IMG_2226 through IMG_2228 supply the Week 13 standings in their in-game order. The snapshot already includes the reported Week 13 wins. The in-game poll numbers are separate from PP BCS rankings. The August Week 13 User Power Poll has a different schedule and records.

The [2027 Week 4 workbook](https://chatgpt.com/library?file_id=libfile_97e2e040c9bc8191a1144b7abf91aa5c&account_id=personal) defines the Week 4 onward poll as 50% committee and 50% computer. The computer components are résumé and strength of schedule (30%), opponent-adjusted performance (25%), quality wins and losses (20%), official record (15%), and capped margin and efficiency (10%). Played user games carry 1.00 performance weight, user vs. CPU 0.60, fair sims 0.30 as roster evidence, and forced results 0.00 for performance with official record credit. Use the current 17-team eligibility list and retain past opponents in the game history.

The Week 9 Boise State–Colorado official final was 38–31. The commissioner approved 0.50 résumé credit for the interrupted game. The 24–17 combined partial score is context for that ruling. The draft site accepts verified rankings entered by the commissioner. The workbook supplies the composite weights and historical component scores, with some component inputs entered by hand.

IMG_2240 through IMG_2246 supply the ACC team stats, IMG_2247 through IMG_2253 the American team stats, and IMG_2254 through IMG_2260 the Big 12 team stats. The Week 13 snapshot keeps all 35 teams and all seven categories. Profiles display the snapshot week separately from the current standings week. Rates and totals use the values shown in the game.


The Week 13 opening-line board uses the planned matchups and venues in the 2027 workbook. Its spread and total model uses only the archived Week 9–12 scorelines, with recent-game weighting, opponent adjustments, capped blowout margins, and a 2.5-point home adjustment. Force wins are excluded, fair sims are discounted, and the interrupted Boise State–Colorado result uses the commissioner's 0.50 weight before recency adjustment. Unobserved teams use the league-average baseline. These are reconstructed dynasty numbers. The lines do not feed into the PP BCS standings.

The Week 13 PP BCS page includes a provisional 17-team poll, based on the Week 13 standings snapshot and the available Week 9–13 results. It uses the workbook's 50/50 blend and category weights with estimated computer inputs. Use Commissioner HQ → Rankings to save the verified poll for the current week before advancing. Published weekly polls remain selectable in the Rankings archive.
