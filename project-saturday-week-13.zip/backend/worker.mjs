class RequestError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function requireValue(condition, message, status = 400) {
  if (!condition) throw new RequestError(status, message);
}

const validText = (value, max) => typeof value === 'string' && value.trim() && value.length <= max;
const optionalText = (value, max) => typeof value === 'string' && value.length <= max;
const validWeek = value => Number.isInteger(value) && value >= 1 && value <= 30;
const validScore = value => Number.isInteger(value) && value >= 0 && value <= 999;
const phases = ['Pregame', 'Postgame'];

function validateLeague(data) {
  requireValue(data && validWeek(data.week), 'Choose a week between 1 and 30.');
  const standingsWeek = data.standingsWeek ?? 11;
  requireValue(validWeek(standingsWeek), 'Choose a valid standings verification week.');
  const weekLabels = data.weekLabels ?? {};
  requireValue(typeof weekLabels === 'object' && !Array.isArray(weekLabels) &&
    Object.entries(weekLabels).every(([week, label]) =>
      validWeek(Number(week)) && String(Number(week)) === week && validText(label, 60)), 'Check the week labels.');
  const conferences = ['ACC', 'American', 'Big 12'];
  requireValue(data.standings && Object.keys(data.standings).length === conferences.length, 'Include all three conferences.');
  const teams = new Set();
  for (const conference of conferences) {
    const rows = data.standings[conference];
    requireValue(Array.isArray(rows) && rows.length <= 40, 'Invalid standings.');
    for (const row of rows) {
      requireValue(Array.isArray(row) && row.length === 3 && validText(row[0], 80) && !teams.has(row[0]), 'Each team needs a unique name.');
      requireValue(row.slice(1).every(record => typeof record === 'string' && /^\d{1,2}-\d{1,2}$/.test(record)), 'Use W-L for each record.');
      const [cw, cl] = row[1].split('-').map(Number);
      const [ow, ol] = row[2].split('-').map(Number);
      requireValue(cw <= ow && cl <= ol, 'Overall records must include conference wins and losses.');
      teams.add(row[0]);
    }
  }

  requireValue(Array.isArray(data.games) && data.games.length <= 500, 'Invalid weekly schedule.');
  const ids = new Set();
  for (const game of data.games) {
    requireValue(game && validText(game.id, 80) && !ids.has(game.id) && validWeek(game.week)
      && conferences.includes(game.conference) && validText(game.away, 80) && validText(game.home, 80)
      && game.away !== game.home && optionalText(game.kickoff, 140) && optionalText(game.label, 50)
      && typeof game.featured === 'boolean', 'Check the game details.');
    requireValue(game.scores === null || (Array.isArray(game.scores) && game.scores.length === 2
      && game.scores.every(validScore) && game.scores[0] !== game.scores[1]), 'Enter two different final scores or leave both blank.');
    requireValue(game.resultMethod === undefined || game.resultMethod === '' ||
      (game.scores !== null && ['Force win', 'Fair sim'].includes(game.resultMethod)), 'Choose a result method only for a final score.');
    requireValue(game.overtime === undefined || (typeof game.overtime === 'boolean' &&
      (!game.overtime || game.scores !== null)), 'Mark overtime only for a final score.');
    requireValue(game.siteUnconfirmed === undefined || typeof game.siteUnconfirmed === 'boolean', 'Invalid game site status.');
    ids.add(game.id);
  }

  requireValue(data.rankings && typeof data.rankings === 'object' && !Array.isArray(data.rankings)
    && Object.keys(data.rankings).length <= 30, 'Invalid rankings.');
  for (const [week, ranked] of Object.entries(data.rankings)) {
    requireValue(validWeek(Number(week)) && Array.isArray(ranked) && ranked.length <= 25
      && ranked.every(team => validText(team, 80)) && new Set(ranked).size === ranked.length, 'Rank up to 25 unique teams each week.');
    requireValue(Number(week) !== data.week || ranked.every(team => teams.has(team)), 'Rank teams from the current standings.');
  }

  requireValue(Array.isArray(data.stories) && data.stories.length <= 12 && data.stories.every(story =>
    story && validText(story.title, 140) && validText(story.body, 2500)
    && ['Headline', 'Featured'].includes(story.type) && validWeek(story.week)), 'Check story titles and text.');
  return {week: data.week, standingsWeek, weekLabels, standings: data.standings, games: data.games.map(
    ({id, week, conference, away, home, kickoff, label, featured, scores, resultMethod, overtime, siteUnconfirmed}) =>
      ({id, week, conference, away, home, kickoff, label, featured, scores, resultMethod, overtime, siteUnconfirmed})),
    rankings: data.rankings, stories: data.stories.map(({title, body, type, week}) => ({title, body, type, week}))};
}

async function readBody(request) {
  // Bound the payload even when a client sends it without Content-Length.
  const reader = request.body?.getReader();
  requireValue(reader, 'Request body required.');
  const decoder = new TextDecoder();
  let size = 0;
  let body = '';
  for (;;) {
    const {done, value} = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > 300000) {
      await reader.cancel();
      throw new RequestError(413, 'Update is too large.');
    }
    body += decoder.decode(value, {stream: true});
  }
  try {
    return JSON.parse(body + decoder.decode());
  } catch {
    throw new RequestError(400, 'Invalid JSON.');
  }
}

async function hash(value) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
}

function equal(a, b) {
  let difference = a.length ^ b.length;
  for (let i = 0; i < a.length; i++) difference |= a.charCodeAt(i) ^ (b.charCodeAt(i) || 0);
  return difference === 0;
}

async function league(db) {
  const row = await db.prepare('SELECT version, snapshot FROM league WHERE id = 1').first();
  return row ? {version: row.version, data: JSON.parse(row.snapshot)} : {version: 0, data: null};
}

async function route(request, env) {
  const {pathname} = new URL(request.url);
  const method = request.method;
  const db = env.DB;
  const authorization = request.headers.get('Authorization') || '';
  const token = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';

  if (pathname === '/league' && method === 'GET') {
    const snapshot = await league(db);
    const {results} = await db.prepare(
      'SELECT id, game_id AS gameId, team, phase, answers, submitted_at AS submittedAt FROM interviews WHERE answers IS NOT NULL ORDER BY submitted_at, id'
    ).all();
    return {...snapshot, responses: results.map(row => ({...row, answers: JSON.parse(row.answers)}))};
  }

  if (pathname.startsWith('/commissioner/')) {
    requireValue(env.COMMISSIONER_KEY?.length >= 32, 'Commissioner access is unavailable.', 503);
    requireValue(token.length <= 256 && equal(await hash(token), await hash(env.COMMISSIONER_KEY)), 'Commissioner access key required.', 401);

    if (pathname === '/commissioner/league' && method === 'PUT') {
      const payload = await readBody(request);
      requireValue(payload && Number.isInteger(payload.version) && payload.version >= 0, 'A valid draft version is required.');
      const snapshot = JSON.stringify(validateLeague(payload.data));
      // A saved interview keeps its game, teams and week. The check and write share a SQL statement.
      const result = await db.prepare(`
        INSERT INTO league (id, version, snapshot)
        SELECT 1, 1, ?1 WHERE ?2 = 0 OR EXISTS (SELECT 1 FROM league WHERE id = 1)
        ON CONFLICT(id) DO UPDATE SET version = league.version + 1, snapshot = excluded.snapshot
        WHERE league.version = ?2 AND NOT EXISTS (
          SELECT 1 FROM interviews i JOIN json_each(league.snapshot, '$.games') previous
            ON json_extract(previous.value, '$.id') = i.game_id
          WHERE NOT EXISTS (
            SELECT 1 FROM json_each(excluded.snapshot, '$.games') next
            WHERE json_extract(next.value, '$.id') = i.game_id
              AND json_extract(next.value, '$.week') = json_extract(previous.value, '$.week')
              AND json_extract(next.value, '$.away') = json_extract(previous.value, '$.away')
              AND json_extract(next.value, '$.home') = json_extract(previous.value, '$.home')
          )
        )
      `).bind(snapshot, payload.version).run();
      requireValue(result.meta.changes === 1, 'A newer update was saved, or a game with coach questions was removed or reassigned. Reopen the dashboard to review.', 409);
      return {version: payload.version + 1};
    }

    if (pathname === '/commissioner/interviews' && method === 'GET') {
      const {results} = await db.prepare(`
        SELECT id, game_id AS gameId, team, phase, prompts, submitted_at AS submittedAt
        FROM interviews ORDER BY rowid DESC
      `).all();
      return {interviews: results.map(row => ({...row, prompts: JSON.parse(row.prompts)}))};
    }

    if (pathname === '/commissioner/interviews' && method === 'POST') {
      const body = await readBody(request);
      requireValue(body && validText(body.gameId, 80) && validText(body.team, 80) && phases.includes(body.phase)
        && Array.isArray(body.prompts) && body.prompts.length >= 1 && body.prompts.length <= 3
        && body.prompts.every(prompt => validText(prompt, 350)), 'Choose a game and coach and enter one to three questions.');
      const id = crypto.randomUUID();
      const linkToken = crypto.randomUUID() + crypto.randomUUID();
      const saved = await db.prepare(`
        INSERT INTO interviews (id, game_id, team, phase, prompts, token_hash)
        SELECT ?1, ?2, ?3, ?4, ?5, ?6 FROM league, json_each(league.snapshot, '$.games') game
        WHERE league.id = 1 AND json_extract(game.value, '$.id') = ?2
          AND ?3 IN (json_extract(game.value, '$.away'), json_extract(game.value, '$.home'))
          AND (?4 = 'Pregame' OR json_type(game.value, '$.scores') = 'array')
        ON CONFLICT(game_id, team, phase) DO NOTHING
      `).bind(id, body.gameId, body.team, body.phase, JSON.stringify(body.prompts.map(p => p.trim())), await hash(linkToken)).run();
      requireValue(saved.meta.changes === 1, 'Save the matchup and any final score first. Each team can have one interview per game and phase.', 409);
      return {id, token: linkToken};
    }

    if (pathname === '/commissioner/rotate-link' && method === 'POST') {
      const body = await readBody(request);
      requireValue(body && validText(body.id, 80), 'Interview ID required.');
      const linkToken = crypto.randomUUID() + crypto.randomUUID();
      const result = await db.prepare('UPDATE interviews SET token_hash = ? WHERE id = ? AND answers IS NULL')
        .bind(await hash(linkToken), body.id).run();
      requireValue(result.meta.changes === 1, 'Only unanswered interviews can get a new link.', 409);
      return {token: linkToken};
    }
  }

  if (pathname === '/coach' && ['GET', 'POST'].includes(method)) {
    requireValue(/^[0-9a-f-]{72}$/.test(token), 'This coach link is invalid.', 404);
    const tokenHash = await hash(token);
    const row = await db.prepare(`
      SELECT i.id, i.team, i.phase, i.prompts, i.submitted_at AS submittedAt,
        json_extract(game.value, '$.week') AS week, json_extract(game.value, '$.away') AS away,
        json_extract(game.value, '$.home') AS home, json_extract(game.value, '$.siteUnconfirmed') AS siteUnconfirmed
      FROM interviews i, league, json_each(league.snapshot, '$.games') game
      WHERE i.token_hash = ? AND league.id = 1 AND json_extract(game.value, '$.id') = i.game_id
    `).bind(tokenHash).first();
    requireValue(row, 'This coach link is invalid or has been replaced.', 404);
    const prompts = JSON.parse(row.prompts);
    if (method === 'GET') return {...row, prompts};
    requireValue(!row.submittedAt, 'These answers are already public.', 409);
    const payload = await readBody(request);
    requireValue(payload && Array.isArray(payload.answers) && payload.answers.length === prompts.length
      && payload.answers.every(answer => validText(answer, 1000)), 'Please answer each question.');
    const submittedAt = new Date().toISOString();
    const saved = await db.prepare(
      'UPDATE interviews SET answers = ?, submitted_at = ? WHERE id = ? AND token_hash = ? AND answers IS NULL'
    ).bind(JSON.stringify(payload.answers.map(answer => answer.trim())), submittedAt, row.id, tokenHash).run();
    requireValue(saved.meta.changes === 1, 'The interview was already submitted or the link was replaced.', 409);
    return {submittedAt};
  }

  throw new RequestError(404, 'Unknown route.');
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin');
    const headers = {
      'Cache-Control': 'no-store',
      'Referrer-Policy': 'no-referrer',
      'X-Content-Type-Options': 'nosniff',
      'Vary': 'Origin',
    };
    if (origin && origin === env.SITE_ORIGIN) headers['Access-Control-Allow-Origin'] = origin;
    if (origin && origin !== env.SITE_ORIGIN) return Response.json({error: 'Origin not allowed.'}, {status: 403, headers});
    if (request.method === 'OPTIONS') {
      headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, OPTIONS';
      headers['Access-Control-Allow-Headers'] = 'Authorization, Content-Type';
      return new Response(null, {status: 204, headers});
    }
    try {
      return Response.json(await route(request, env), {headers});
    } catch (error) {
      if (!(error instanceof RequestError)) console.error('Project Saturday request failed', error);
      return Response.json({error: error.status ? error.message : 'The league service is unavailable.'},
        {status: error.status || 500, headers});
    }
  },
};
