import {createServer} from 'node:http';
import {readFileSync} from 'node:fs';
import {Readable} from 'node:stream';
import {DatabaseSync} from 'node:sqlite';
import worker from './worker.mjs';

const port = Number(process.env.PROJECT_SATURDAY_PORT || 8787);
const origin = `http://127.0.0.1:${port}`;
const commissionerKey = process.env.PROJECT_SATURDAY_PREVIEW_KEY || crypto.randomUUID() + crypto.randomUUID();
const database = new DatabaseSync(':memory:');
database.exec(readFileSync(new URL('./migrations/0001_initial.sql', import.meta.url), 'utf8'));

const DB = {
  prepare(sql) {
    const numbered = /\?\d/.test(sql);
    const statement = database.prepare(numbered ? sql.replace(/\?(\d+)/g, ':p$1') : sql);
    function methods(params) {
      const argumentsForSql = numbered ? [Object.fromEntries(params.map((value, i) => ['p' + (i + 1), value]))] : params;
      return {
        bind: (...values) => methods(values),
        first: () => statement.get(...argumentsForSql) || null,
        all: () => ({results: statement.all(...argumentsForSql)}),
        run: () => ({meta: {changes: statement.run(...argumentsForSql).changes}}),
      };
    }
    return methods([]);
  },
};

const publicFiles = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/dashboard.js': ['dashboard.js', 'text/javascript; charset=utf-8'],
  '/dashboard.css': ['dashboard.css', 'text/css; charset=utf-8'],
};

createServer(async (request, response) => {
  const url = new URL(request.url, origin);
  if (url.pathname.startsWith('/api/')) {
    const body = ['POST', 'PUT'].includes(request.method) ? Readable.toWeb(request) : undefined;
    const apiRequest = new Request(origin + url.pathname.slice(4), {
      method: request.method, headers: request.headers, body, duplex: 'half',
    });
    const result = await worker.fetch(apiRequest, {DB, SITE_ORIGIN: origin, COMMISSIONER_KEY: commissionerKey});
    response.writeHead(result.status, Object.fromEntries(result.headers));
    response.end(Buffer.from(await result.arrayBuffer()));
  } else if (url.pathname === '/league-config.js') {
    response.writeHead(200, {'Content-Type': 'text/javascript; charset=utf-8'});
    response.end('window.PROJECT_SATURDAY_API = ' + JSON.stringify(origin + '/api') + ';');
  } else if (Object.hasOwn(publicFiles, url.pathname)) {
    const [file, type] = publicFiles[url.pathname];
    response.writeHead(200, {'Content-Type': type});
    response.end(readFileSync(new URL('../' + file, import.meta.url)));
  } else {
    response.writeHead(404).end();
  }
}).listen(port, '127.0.0.1', () => {
  console.log(`Project Saturday preview: ${origin}`);
  if (!process.env.PROJECT_SATURDAY_PREVIEW_KEY) console.log(`Temporary preview key: ${commissionerKey}`);
});
