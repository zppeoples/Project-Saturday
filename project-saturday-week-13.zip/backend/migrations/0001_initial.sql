CREATE TABLE league (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  version INTEGER NOT NULL,
  snapshot TEXT NOT NULL
);

CREATE TABLE interviews (
  id TEXT PRIMARY KEY,
  game_id TEXT NOT NULL,
  team TEXT NOT NULL,
  phase TEXT NOT NULL CHECK (phase IN ('Pregame', 'Postgame')),
  prompts TEXT NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  answers TEXT,
  submitted_at TEXT,
  UNIQUE (game_id, team, phase)
);
